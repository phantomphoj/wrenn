import { describe, it, expect } from 'vitest'
import {
  validateSettingsPartial,
  validateHistoryEntry,
  validateDeletionQuery
} from './ipc-validation'

describe('validateSettingsPartial', () => {
  it('accepts only supported dashboard views', () => {
    expect(validateSettingsPartial({ dashboardView: 'simple' })).toEqual({
      dashboardView: 'simple'
    })
    expect(validateSettingsPartial({ dashboardView: 'advanced' })).toEqual({
      dashboardView: 'advanced'
    })
    for (const dashboardView of ['expert', '', false, 1, null, {}]) {
      expect(validateSettingsPartial({ dashboardView })).toBeNull()
    }
  })
  it('accepts valid boolean settings', () => {
    const input = { minimizeToTray: true, autoUpdate: false }
    expect(validateSettingsPartial(input)).toEqual(input)
  })

  it('rejects null', () => {
    expect(validateSettingsPartial(null)).toBeNull()
  })

  it('rejects arrays', () => {
    expect(validateSettingsPartial([1, 2])).toBeNull()
  })

  it('rejects primitives', () => {
    expect(validateSettingsPartial('string')).toBeNull()
    expect(validateSettingsPartial(42)).toBeNull()
  })

  it('rejects unknown top-level keys', () => {
    expect(validateSettingsPartial({ hackerField: true })).toBeNull()
  })

  it('rejects wrong types for boolean fields', () => {
    expect(validateSettingsPartial({ minimizeToTray: 'yes' })).toBeNull()
    expect(validateSettingsPartial({ runAtStartup: 1 })).toBeNull()
  })

  it('accepts valid exclusions array', () => {
    const input = { exclusions: ['C:\\keep', '*.log'] }
    expect(validateSettingsPartial(input)).toEqual(input)
  })

  it('rejects non-array exclusions', () => {
    expect(validateSettingsPartial({ exclusions: 'C:\\keep' })).toBeNull()
  })

  it('rejects exclusions with non-string entries', () => {
    expect(validateSettingsPartial({ exclusions: [123] })).toBeNull()
  })

  it('rejects too many exclusions', () => {
    const exclusions = Array.from({ length: 201 }, (_, i) => `path-${i}`)
    expect(validateSettingsPartial({ exclusions })).toBeNull()
  })

  it('rejects empty string exclusions', () => {
    expect(validateSettingsPartial({ exclusions: [''] })).toBeNull()
  })

  it('rejects overly long exclusion strings', () => {
    expect(validateSettingsPartial({ exclusions: ['x'.repeat(501)] })).toBeNull()
  })

  it('accepts softwareUpdaterNotifications boolean', () => {
    expect(validateSettingsPartial({ softwareUpdaterNotifications: false })).toEqual({
      softwareUpdaterNotifications: false
    })
  })

  it('rejects non-boolean softwareUpdaterNotifications', () => {
    expect(validateSettingsPartial({ softwareUpdaterNotifications: 'off' })).toBeNull()
  })

  it('accepts preferElevatedLaunch boolean', () => {
    expect(validateSettingsPartial({ preferElevatedLaunch: true })).toEqual({
      preferElevatedLaunch: true
    })
  })

  it('rejects non-boolean preferElevatedLaunch', () => {
    expect(validateSettingsPartial({ preferElevatedLaunch: 1 })).toBeNull()
  })

  it('accepts valid ignoredSoftwareUpdates array', () => {
    const input = { ignoredSoftwareUpdates: ['Google.Chrome', 'Mozilla.Firefox'] }
    expect(validateSettingsPartial(input)).toEqual(input)
  })

  it('rejects non-array ignoredSoftwareUpdates', () => {
    expect(validateSettingsPartial({ ignoredSoftwareUpdates: 'Google.Chrome' })).toBeNull()
  })

  it('rejects ignoredSoftwareUpdates with non-string entries', () => {
    expect(validateSettingsPartial({ ignoredSoftwareUpdates: [42] })).toBeNull()
  })

  it('rejects empty string in ignoredSoftwareUpdates', () => {
    expect(validateSettingsPartial({ ignoredSoftwareUpdates: [''] })).toBeNull()
  })

  it('accepts valid ignoredDriverUpdates array', () => {
    const input = { ignoredDriverUpdates: ['1e2f3a4b-0000-4000-8000-000000000000'] }
    expect(validateSettingsPartial(input)).toEqual(input)
  })

  it('rejects ignoredDriverUpdates with non-string or empty entries', () => {
    expect(validateSettingsPartial({ ignoredDriverUpdates: [42] })).toBeNull()
    expect(validateSettingsPartial({ ignoredDriverUpdates: [''] })).toBeNull()
    expect(validateSettingsPartial({ ignoredDriverUpdates: 'x' })).toBeNull()
  })

  it('accepts valid schedule', () => {
    const input = { schedule: { enabled: true, frequency: 'daily', day: 0, hour: 9 } }
    expect(validateSettingsPartial(input)).toEqual(input)
  })

  it('rejects invalid schedule frequency', () => {
    expect(validateSettingsPartial({ schedule: { frequency: 'yearly' } })).toBeNull()
  })

  it('rejects out-of-range schedule hour', () => {
    expect(validateSettingsPartial({ schedule: { hour: 24 } })).toBeNull()
    expect(validateSettingsPartial({ schedule: { hour: -1 } })).toBeNull()
  })

  it('rejects out-of-range schedule day', () => {
    expect(validateSettingsPartial({ schedule: { day: 7 } })).toBeNull()
  })

  it('rejects schedule as array', () => {
    expect(validateSettingsPartial({ schedule: [] })).toBeNull()
  })

  it('rejects unknown schedule keys', () => {
    expect(validateSettingsPartial({ schedule: { enabled: true, foo: 'bar' } })).toBeNull()
  })

  it('accepts valid cleaner settings', () => {
    const input = { cleaner: { skipRecentMinutes: 120, secureDelete: true } }
    expect(validateSettingsPartial(input)).toEqual(input)
  })

  it('rejects cleaner with invalid skipRecentMinutes', () => {
    expect(validateSettingsPartial({ cleaner: { skipRecentMinutes: -1 } })).toBeNull()
    expect(validateSettingsPartial({ cleaner: { skipRecentMinutes: 600000 } })).toBeNull()
  })

  it('rejects cleaner with wrong boolean types', () => {
    expect(validateSettingsPartial({ cleaner: { secureDelete: 'yes' } })).toBeNull()
  })

  it('rejects unknown cleaner keys', () => {
    expect(validateSettingsPartial({ cleaner: { unknownKey: true } })).toBeNull()
  })

  it('accepts every cleaner key the settings UI actually sends', () => {
    // SettingsPage spreads the whole cleaner object on each toggle, so a key
    // missing from the allowlist silently rejects the entire settings write.
    const input = {
      cleaner: {
        skipRecentMinutes: 60,
        secureDelete: false,
        closeBrowsersBeforeClean: false,
        createRestorePoint: false,
        protectRecycleBin: true,
        keepDeletionLog: false
      }
    }
    expect(validateSettingsPartial(input)).toEqual(input)
  })

  it('rejects non-boolean protectRecycleBin and keepDeletionLog', () => {
    expect(validateSettingsPartial({ cleaner: { protectRecycleBin: 'yes' } })).toBeNull()
    expect(validateSettingsPartial({ cleaner: { keepDeletionLog: 1 } })).toBeNull()
  })

  it('accepts valid backupMode values', () => {
    expect(validateSettingsPartial({ backupMode: 'targeted' })).toEqual({ backupMode: 'targeted' })
    expect(validateSettingsPartial({ backupMode: 'full' })).toEqual({ backupMode: 'full' })
  })

  it('rejects invalid backupMode values', () => {
    expect(validateSettingsPartial({ backupMode: 'partial' })).toBeNull()
    expect(validateSettingsPartial({ backupMode: 42 })).toBeNull()
  })

  it('accepts a valid backupPath', () => {
    // path.isAbsolute is platform-aware, so use a path absolute on the current OS.
    const backupPath =
      process.platform === 'win32' ? 'C:\\Users\\dave\\Backups' : '/Users/dave/Backups'
    const input = { backupPath }
    expect(validateSettingsPartial(input)).toEqual(input)
  })

  it('accepts an empty backupPath (means default)', () => {
    expect(validateSettingsPartial({ backupPath: '' })).toEqual({ backupPath: '' })
  })

  it('rejects non-string backupPath', () => {
    expect(validateSettingsPartial({ backupPath: 42 })).toBeNull()
  })

  it('rejects backupPath with path traversal', () => {
    expect(validateSettingsPartial({ backupPath: 'C:\\..\\evil' })).toBeNull()
  })

  it('rejects overly long backupPath', () => {
    expect(validateSettingsPartial({ backupPath: 'x'.repeat(1001) })).toBeNull()
  })

  it('rejects a relative backupPath', () => {
    // Relative paths would be silently ignored at runtime, so reject at the boundary.
    expect(validateSettingsPartial({ backupPath: 'relative/dir' })).toBeNull()
  })

  it('accepts valid theme values', () => {
    expect(validateSettingsPartial({ theme: 'dark' })).toEqual({ theme: 'dark' })
    expect(validateSettingsPartial({ theme: 'light' })).toEqual({ theme: 'light' })
    expect(validateSettingsPartial({ theme: 'system' })).toEqual({ theme: 'system' })
  })

  it('rejects invalid theme values', () => {
    expect(validateSettingsPartial({ theme: 'blue' })).toBeNull()
    expect(validateSettingsPartial({ theme: 123 })).toBeNull()
  })

  it('accepts valid windowsPackageManager values', () => {
    expect(validateSettingsPartial({ windowsPackageManager: 'winget' })).toEqual({
      windowsPackageManager: 'winget'
    })
    expect(validateSettingsPartial({ windowsPackageManager: 'choco' })).toEqual({
      windowsPackageManager: 'choco'
    })
  })

  it('rejects invalid windowsPackageManager values', () => {
    expect(validateSettingsPartial({ windowsPackageManager: 'npm' })).toBeNull()
    expect(validateSettingsPartial({ windowsPackageManager: 123 })).toBeNull()
    expect(validateSettingsPartial({ windowsPackageManager: '' })).toBeNull()
  })

  it('accepts valid windowsPackageManagers arrays', () => {
    expect(validateSettingsPartial({ windowsPackageManagers: ['winget', 'scoop'] })).toEqual({
      windowsPackageManagers: ['winget', 'scoop']
    })
    expect(
      validateSettingsPartial({ windowsPackageManagers: ['winget', 'choco', 'scoop', 'npm'] })
    ).toEqual({ windowsPackageManagers: ['winget', 'choco', 'scoop', 'npm'] })
    expect(validateSettingsPartial({ windowsPackageManagers: [] })).toEqual({
      windowsPackageManagers: []
    })
  })

  it('rejects invalid windowsPackageManagers arrays', () => {
    expect(validateSettingsPartial({ windowsPackageManagers: ['winget', 'brew'] })).toBeNull()
    expect(validateSettingsPartial({ windowsPackageManagers: 'winget' })).toBeNull()
    expect(validateSettingsPartial({ windowsPackageManagers: [123] })).toBeNull()
    expect(
      validateSettingsPartial({
        windowsPackageManagers: ['winget', 'choco', 'scoop', 'npm', 'winget']
      })
    ).toBeNull()
  })

  it('accepts empty object', () => {
    expect(validateSettingsPartial({})).toEqual({})
  })

  it('accepts valid schedules array', () => {
    const input = {
      schedules: [
        {
          id: 'abc-123',
          name: 'Weekly Clean',
          enabled: true,
          frequency: 'weekly',
          day: 1,
          hour: 9,
          minute: 0,
          tasks: ['cleaner:system', 'cleaner:browsers'],
          autoApply: false,
          lastRunAt: null,
          lastRunStatus: 'never',
          createdAt: '2025-01-01T00:00:00Z'
        }
      ]
    }
    expect(validateSettingsPartial(input)).toEqual(input)
  })

  it('rejects a schedule whose free-space threshold is below the UI minimum', () => {
    const schedule = {
      id: 'x',
      name: 'X',
      enabled: true,
      frequency: 'daily',
      day: 0,
      hour: 9,
      minute: 0,
      tasks: ['cleaner:system'],
      autoApply: false,
      lastRunAt: null,
      lastRunStatus: 'never',
      createdAt: '2025-01-01T00:00:00Z'
    }
    expect(
      validateSettingsPartial({ schedules: [{ ...schedule, conditions: { freeBelowPercent: 0 } }] })
    ).toBeNull()
    const valid = { schedules: [{ ...schedule, conditions: { freeBelowPercent: 1 } }] }
    expect(validateSettingsPartial(valid)).toEqual(valid)
  })

  it('rejects schedules with invalid task types', () => {
    expect(
      validateSettingsPartial({
        schedules: [
          {
            id: 'x',
            name: 'X',
            enabled: true,
            frequency: 'daily',
            day: 0,
            hour: 9,
            minute: 0,
            tasks: ['badtask'],
            autoApply: false,
            lastRunAt: null,
            lastRunStatus: 'never',
            createdAt: '2025-01-01T00:00:00Z'
          }
        ]
      })
    ).toBeNull()
  })

  it('rejects non-array schedules', () => {
    expect(validateSettingsPartial({ schedules: 'not-array' })).toBeNull()
  })

  it('rejects too many schedules', () => {
    const schedules = Array.from({ length: 11 }, (_, i) => ({
      id: `id-${i}`,
      name: `S${i}`,
      enabled: true,
      frequency: 'daily',
      day: 0,
      hour: 9,
      minute: 0,
      tasks: ['cleaner:system'],
      autoApply: false,
      lastRunAt: null,
      lastRunStatus: 'never',
      createdAt: '2025-01-01T00:00:00Z'
    }))
    expect(validateSettingsPartial({ schedules })).toBeNull()
  })

  it('rejects schedule entry with missing fields', () => {
    expect(
      validateSettingsPartial({
        schedules: [{ id: 'x', name: 'X' }]
      })
    ).toBeNull()
  })

  // ── gameMode validation ──────────────────────────

  it('accepts valid gameMode settings', () => {
    const input = {
      gameMode: {
        enabledOptimizations: ['svc-wsearch', 'mem-clear-standby', 'net-flush-dns'],
        customProcessKillList: ['spotify.exe']
      }
    }
    expect(validateSettingsPartial(input)).toEqual(input)
  })

  it('accepts gameMode with empty arrays', () => {
    const input = { gameMode: { enabledOptimizations: [], customProcessKillList: [] } }
    expect(validateSettingsPartial(input)).toEqual(input)
  })

  it('rejects gameMode with invalid optimization IDs', () => {
    expect(
      validateSettingsPartial({
        gameMode: { enabledOptimizations: ['invalid-id'], customProcessKillList: [] }
      })
    ).toBeNull()
  })

  it('rejects gameMode with non-array enabledOptimizations', () => {
    expect(
      validateSettingsPartial({
        gameMode: { enabledOptimizations: 'svc-wsearch', customProcessKillList: [] }
      })
    ).toBeNull()
  })

  it('rejects gameMode with too many optimizations', () => {
    const enabledOptimizations = Array.from({ length: 31 }, () => 'svc-wsearch')
    expect(
      validateSettingsPartial({
        gameMode: { enabledOptimizations, customProcessKillList: [] }
      })
    ).toBeNull()
  })

  it('rejects gameMode with non-string process names', () => {
    expect(
      validateSettingsPartial({
        gameMode: { enabledOptimizations: [], customProcessKillList: [123] }
      })
    ).toBeNull()
  })

  it('rejects gameMode with empty process name strings', () => {
    expect(
      validateSettingsPartial({
        gameMode: { enabledOptimizations: [], customProcessKillList: [''] }
      })
    ).toBeNull()
  })

  it('rejects gameMode with path traversal in process names', () => {
    expect(
      validateSettingsPartial({
        gameMode: { enabledOptimizations: [], customProcessKillList: ['..\\..\\evil.exe'] }
      })
    ).toBeNull()
  })

  it('rejects gameMode with special characters in process names', () => {
    expect(
      validateSettingsPartial({
        gameMode: { enabledOptimizations: [], customProcessKillList: ['evil;rm -rf /'] }
      })
    ).toBeNull()
  })

  it('rejects gameMode with too many custom processes', () => {
    const customProcessKillList = Array.from({ length: 51 }, (_, i) => `proc${i}.exe`)
    expect(
      validateSettingsPartial({
        gameMode: { enabledOptimizations: [], customProcessKillList }
      })
    ).toBeNull()
  })

  it('rejects gameMode with overly long process names', () => {
    expect(
      validateSettingsPartial({
        gameMode: { enabledOptimizations: [], customProcessKillList: ['x'.repeat(101)] }
      })
    ).toBeNull()
  })

  it('rejects gameMode with unknown keys', () => {
    expect(
      validateSettingsPartial({
        gameMode: { enabledOptimizations: [], customProcessKillList: [], extraField: true }
      })
    ).toBeNull()
  })

  it('rejects gameMode as non-object', () => {
    expect(validateSettingsPartial({ gameMode: 'string' })).toBeNull()
    expect(validateSettingsPartial({ gameMode: [] })).toBeNull()
  })

  it('accepts all valid optimization IDs', () => {
    const allIds = [
      'svc-wsearch',
      'svc-sysmain',
      'svc-wuauserv',
      'svc-spooler',
      'svc-diagtrack',
      'proc-kill-browsers',
      'proc-kill-chat',
      'proc-kill-updaters',
      'proc-kill-custom',
      'mem-clear-standby',
      'sys-focus-assist',
      'sys-power-plan',
      'sys-prevent-sleep',
      'sys-disable-game-bar',
      'sys-disable-fse-opt',
      'sys-disable-transparency',
      'net-flush-dns',
      'net-disable-nagle'
    ]
    expect(
      validateSettingsPartial({
        gameMode: { enabledOptimizations: allIds, customProcessKillList: [] }
      })
    ).not.toBeNull()
  })

  it('accepts process names with dots, hyphens, underscores, and spaces', () => {
    expect(
      validateSettingsPartial({
        gameMode: {
          enabledOptimizations: [],
          customProcessKillList: ['my-app.exe', 'My App_v2.exe', 'test 123']
        }
      })
    ).not.toBeNull()
  })

  // registryIgnoredTweaks — persisted "ignore this tweak" signatures (issue #172)
  it('accepts a registryIgnoredTweaks array of signature strings', () => {
    const input = {
      registryIgnoredTweaks: ['hklm\\system\\currentcontrolset\\services\\sysmain|start']
    }
    expect(validateSettingsPartial(input)).toEqual(input)
  })

  it('accepts an empty registryIgnoredTweaks array', () => {
    expect(validateSettingsPartial({ registryIgnoredTweaks: [] })).toEqual({
      registryIgnoredTweaks: []
    })
  })

  it('rejects registryIgnoredTweaks that is not an array', () => {
    expect(validateSettingsPartial({ registryIgnoredTweaks: 'sysmain|start' })).toBeNull()
  })

  it('rejects non-string or empty entries in registryIgnoredTweaks', () => {
    expect(validateSettingsPartial({ registryIgnoredTweaks: [42] })).toBeNull()
    expect(validateSettingsPartial({ registryIgnoredTweaks: [''] })).toBeNull()
  })

  it('rejects an oversized registryIgnoredTweaks list', () => {
    expect(validateSettingsPartial({ registryIgnoredTweaks: Array(201).fill('a|b') })).toBeNull()
  })
})

describe('validateHistoryEntry', () => {
  const validEntry = {
    id: 'entry-1',
    type: 'cleaner',
    timestamp: '2025-01-01T00:00:00Z',
    duration: 5000,
    totalItemsFound: 100,
    totalItemsCleaned: 90,
    totalItemsSkipped: 10,
    totalSpaceSaved: 1048576,
    errorCount: 0,
    categories: [{ name: 'Temp Files', itemsFound: 50, itemsCleaned: 45, spaceSaved: 524288 }]
  }

  it('accepts a valid history entry', () => {
    expect(validateHistoryEntry(validEntry)).toEqual(validEntry)
  })

  it('rejects null', () => {
    expect(validateHistoryEntry(null)).toBeNull()
  })

  it('rejects non-object', () => {
    expect(validateHistoryEntry('string')).toBeNull()
  })

  it('rejects invalid type values', () => {
    expect(validateHistoryEntry({ ...validEntry, type: 'unknown' })).toBeNull()
  })

  it('accepts all valid type values', () => {
    for (const type of ['cleaner', 'registry', 'debloater', 'network', 'drivers']) {
      expect(validateHistoryEntry({ ...validEntry, type })).not.toBeNull()
    }
  })

  it('rejects negative duration', () => {
    expect(validateHistoryEntry({ ...validEntry, duration: -1 })).toBeNull()
  })

  it('rejects overly long id', () => {
    expect(validateHistoryEntry({ ...validEntry, id: 'x'.repeat(101) })).toBeNull()
  })

  it('rejects non-array categories', () => {
    expect(validateHistoryEntry({ ...validEntry, categories: 'none' })).toBeNull()
  })

  it('rejects too many categories', () => {
    const categories = Array.from({ length: 51 }, (_, i) => ({
      name: `cat-${i}`,
      itemsFound: 1,
      itemsCleaned: 1,
      spaceSaved: 100
    }))
    expect(validateHistoryEntry({ ...validEntry, categories })).toBeNull()
  })

  it('accepts an entry with a deletion-log window', () => {
    const entry = {
      ...validEntry,
      cleanedFrom: '2026-07-20T10:00:00.000Z',
      cleanedTo: '2026-07-20T10:01:00.000Z'
    }
    expect(validateHistoryEntry(entry)).toEqual(entry)
  })

  it('rejects a malformed deletion-log window', () => {
    expect(validateHistoryEntry({ ...validEntry, cleanedFrom: 42 })).toBeNull()
    expect(validateHistoryEntry({ ...validEntry, cleanedTo: 'x'.repeat(51) })).toBeNull()
  })

  it('rejects missing required fields', () => {
    const { id, ...noId } = validEntry
    expect(validateHistoryEntry(noId)).toBeNull()
  })
})

describe('validateDeletionQuery', () => {
  it('treats undefined and null as "everything"', () => {
    expect(validateDeletionQuery(undefined)).toEqual({})
    expect(validateDeletionQuery(null)).toEqual({})
  })

  it('accepts an empty object', () => {
    expect(validateDeletionQuery({})).toEqual({})
  })

  it('accepts a full window with paging', () => {
    const query = {
      from: '2026-07-20T10:00:00.000Z',
      to: '2026-07-20T10:01:00.000Z',
      offset: 200,
      limit: 200
    }
    expect(validateDeletionQuery(query)).toEqual(query)
  })

  it('rejects unknown keys', () => {
    expect(validateDeletionQuery({ path: 'C:\\' })).toBeNull()
  })

  it('accepts known origins and rejects anything else', () => {
    for (const origin of ['local', 'cloud', 'cli']) {
      expect(validateDeletionQuery({ origin })).toEqual({ origin })
    }
    expect(validateDeletionQuery({ origin: 'remote' })).toBeNull()
    expect(validateDeletionQuery({ origin: 1 })).toBeNull()
  })

  it('rejects arrays and primitives', () => {
    expect(validateDeletionQuery([])).toBeNull()
    expect(validateDeletionQuery('all')).toBeNull()
  })

  it('rejects unparseable timestamps', () => {
    expect(validateDeletionQuery({ from: 'yesterday' })).toBeNull()
    expect(validateDeletionQuery({ to: 12345 })).toBeNull()
    expect(validateDeletionQuery({ from: 'x'.repeat(51) })).toBeNull()
  })

  it('rejects negative or non-finite paging values', () => {
    expect(validateDeletionQuery({ offset: -1 })).toBeNull()
    expect(validateDeletionQuery({ limit: Infinity })).toBeNull()
    expect(validateDeletionQuery({ limit: '200' })).toBeNull()
  })
})
