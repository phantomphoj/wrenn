import { app, protocol, type BrowserWindow } from 'electron'
import { createReadStream, existsSync, mkdirSync, readdirSync, rmSync, statSync, copyFileSync } from 'fs'
import { basename, extname, join } from 'path'
import { Readable } from 'stream'
import { showOpenDialog } from '../ipc/open-dialog'
import { getSettings, setSettings } from './settings-store'
import type { AppearanceSettings } from '../../shared/types'

/** Custom scheme the renderer uses to load the wallpaper. It only ever serves the one saved file. */
export const WALLPAPER_SCHEME = 'zrodrr-media'

const IMAGE_EXT = ['.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp']
const VIDEO_EXT = ['.mp4', '.m4v', '.webm']
const MAX_BYTES = 500 * 1024 * 1024

const MIME: Record<string, string> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.bmp': 'image/bmp',
  '.mp4': 'video/mp4',
  '.m4v': 'video/mp4',
  '.webm': 'video/webm'
}

/** Must run before app is ready. */
export function registerWallpaperScheme(): void {
  protocol.registerSchemesAsPrivileged([
    {
      scheme: WALLPAPER_SCHEME,
      privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true }
    }
  ])
}

function wallpaperDir(): string {
  return join(app.getPath('userData'), 'wallpaper')
}

function currentWallpaperPath(): string | null {
  const file = getSettings().appearance?.wallpaperFile
  if (!file) return null
  const p = join(wallpaperDir(), basename(file))
  return existsSync(p) ? p : null
}

/** Serve the saved wallpaper (with Range support so video can play and seek). */
export function registerWallpaperProtocol(): void {
  protocol.handle(WALLPAPER_SCHEME, (request) => {
    const file = currentWallpaperPath()
    if (!file) return new Response(null, { status: 404 })
    const size = statSync(file).size
    const type = MIME[extname(file).toLowerCase()] ?? 'application/octet-stream'
    const range = /^bytes=(\d*)-(\d*)$/.exec(request.headers.get('range') ?? '')
    if (range && (range[1] || range[2])) {
      let start = range[1] ? parseInt(range[1], 10) : size - parseInt(range[2], 10)
      let end = range[1] && range[2] ? parseInt(range[2], 10) : size - 1
      start = Math.max(0, start)
      end = Math.min(size - 1, end)
      if (start > end || start >= size) {
        return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${size}` } })
      }
      const body = Readable.toWeb(createReadStream(file, { start, end })) as ReadableStream
      return new Response(body, {
        status: 206,
        headers: {
          'Content-Type': type,
          'Accept-Ranges': 'bytes',
          'Content-Length': String(end - start + 1),
          'Content-Range': `bytes ${start}-${end}/${size}`
        }
      })
    }
    const body = Readable.toWeb(createReadStream(file)) as ReadableStream
    return new Response(body, {
      status: 200,
      headers: { 'Content-Type': type, 'Accept-Ranges': 'bytes', 'Content-Length': String(size) }
    })
  })
}

function clearFiles(): void {
  const dir = wallpaperDir()
  if (!existsSync(dir)) return
  for (const f of readdirSync(dir)) {
    try {
      rmSync(join(dir, f), { force: true })
    } catch {
      /* skip */
    }
  }
}

export type PickWallpaperResult =
  | { ok: true; appearance: Partial<AppearanceSettings> }
  | { ok: false; reason: 'canceled' | 'too-large' | 'unsupported' | 'failed' }

export async function pickWallpaper(win: BrowserWindow | null): Promise<PickWallpaperResult> {
  const result = await showOpenDialog(win, {
    title: 'Choose a wallpaper (image or MP4 video)',
    properties: ['openFile'],
    filters: [
      { name: 'Images and video', extensions: [...IMAGE_EXT, ...VIDEO_EXT].map((e) => e.slice(1)) },
      { name: 'Images', extensions: IMAGE_EXT.map((e) => e.slice(1)) },
      { name: 'Video', extensions: VIDEO_EXT.map((e) => e.slice(1)) }
    ]
  })
  if (result.canceled || !result.filePaths.length) return { ok: false, reason: 'canceled' }
  const src = result.filePaths[0]
  const ext = extname(src).toLowerCase()
  const isImage = IMAGE_EXT.includes(ext)
  const isVideo = VIDEO_EXT.includes(ext)
  if (!isImage && !isVideo) return { ok: false, reason: 'unsupported' }
  try {
    if (statSync(src).size > MAX_BYTES) return { ok: false, reason: 'too-large' }
    mkdirSync(wallpaperDir(), { recursive: true })
    clearFiles()
    const name = `wallpaper${ext}`
    copyFileSync(src, join(wallpaperDir(), name))
    const appearance: Partial<AppearanceSettings> = {
      wallpaperFile: name,
      wallpaperType: isVideo ? 'video' : 'image',
      wallpaperVersion: Date.now()
    }
    await setSettings({ appearance } as never)
    return { ok: true, appearance }
  } catch {
    return { ok: false, reason: 'failed' }
  }
}

export async function clearWallpaper(): Promise<void> {
  clearFiles()
  await setSettings({
    appearance: { wallpaperFile: null, wallpaperType: null, wallpaperVersion: Date.now() }
  } as never)
}
