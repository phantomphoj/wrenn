import { BrowserWindow, ipcMain, shell } from 'electron'
import { readdir, rmdir, stat, lstat, open, rm } from 'fs/promises'
import { constants as fsConstants } from 'fs'
import { join, isAbsolute, basename, resolve, normalize } from 'path'
import { randomBytes } from 'crypto'
import { IPC } from '../../shared/channels'
import type { ShredderEntry, ShredderProgress, ShredderResult } from '../../shared/types'
import type { WindowGetter } from './index'
import { showOpenDialog } from './open-dialog'

let cancelled = false

// ── Safety: paths we must never shred ──

const PROTECTED_WIN32 = [
  'windows',
  'system32',
  'syswow64',
  'winsxs',
  'program files',
  'program files (x86)',
  'programdata',
  'recovery',
  'boot',
  '$recycle.bin',
  'system volume information',
  'perflogs',
  'msocache',
  'config.msi',
  'drivers',
  'inf',
  'logs'
]
const PROTECTED_UNIX = [
  'bin',
  'sbin',
  'usr',
  'etc',
  'var',
  'lib',
  'lib64',
  'opt',
  'boot',
  'dev',
  'proc',
  'sys',
  'run',
  'tmp',
  'snap',
  'root',
  'lost+found',
  'system',
  'library',
  'applications',
  'cores',
  'private',
  'volumes'
]
const PROTECTED_GENERIC = [
  '.git',
  '.svn',
  '.hg',
  'node_modules',
  '.npm',
  '.cache',
  '.local',
  '__pycache__',
  '.venv',
  '.env',
  '.ssh',
  '.gnupg',
  '.config',
  'appdata',
  '.android',
  '.gradle'
]

function isProtectedPath(targetPath: string): boolean {
  const normalized = normalize(resolve(targetPath)).replace(/\\/g, '/')
  const name = basename(normalized).toLowerCase()
  const pathLower = normalized.toLowerCase()
  const segments = pathLower.split('/').filter(Boolean)

  // Never shred filesystem roots (/, C:\)
  if (segments.length === 0) return true
  // On Windows C:/ has segments ['c:'] — depth 1 is the drive root
  if (process.platform === 'win32' && segments.length <= 1) return true

  // Never shred root-level directories (C:\Windows, /usr, etc.)
  const isRootLevel = process.platform === 'win32' ? segments.length <= 2 : segments.length <= 1
  if (isRootLevel) return true

  // Check against protected name lists
  const protectedNames =
    process.platform === 'win32'
      ? [...PROTECTED_WIN32, ...PROTECTED_GENERIC]
      : [...PROTECTED_UNIX, ...PROTECTED_GENERIC]
  if (protectedNames.includes(name)) return true

  // Never shred user profile root folders
  const userProfileDirs = [
    'desktop',
    'documents',
    'downloads',
    'pictures',
    'videos',
    'music',
    'onedrive'
  ]
  if (userProfileDirs.includes(name)) {
    const home = (process.env.HOME || process.env.USERPROFILE || '')
      .toLowerCase()
      .replace(/\\/g, '/')
    if (home) {
      const parent = pathLower.substring(0, pathLower.lastIndexOf('/'))
      if (parent === home || parent === home + '/') return true
    }
  }

  return false
}

/** What a file was when we found it, so we can tell later whether it still is. */
interface FileIdentity {
  dev: bigint
  ino: bigint
  size: bigint
}

/** Identity of a regular file, or null if the path isn't one we should shred. */
async function readIdentity(filePath: string): Promise<FileIdentity | null> {
  try {
    const s = await lstat(filePath, { bigint: true })
    if (s.isSymbolicLink() || !s.isFile()) return null
    return { dev: s.dev, ino: s.ino, size: s.size }
  } catch {
    return null
  }
}

function sendProgress(win: BrowserWindow | null, data: ShredderProgress): void {
  if (win && !win.isDestroyed()) {
    win.webContents.send(IPC.SHREDDER_PROGRESS, data)
  }
}

/**
 * Overwrite a single file with random data then zeros (2-pass shred).
 * Checks the module-level `cancelled` flag between chunks so large files can
 * be interrupted. Returns false when cancelled part-way: the file is then only
 * partly overwritten, so the caller must neither delete it nor count it as
 * shredded.
 *
 * A path is not a stable reference to a file. Every resolution of it consults
 * the directories above it, and for a shred target those directories are
 * wherever the user pointed — possibly a shared or removable volume something
 * else can write. So `expected` is the identity recorded when the tree was
 * walked and the path was known to lie inside the selection; the handle opened
 * here has to still be that same file.
 *
 * Re-lstat'ing the path here instead would not be enough: swapping a *parent*
 * directory for a symlink redirects both the lstat and the open equally, so
 * the two agree with each other while both point somewhere the user never
 * selected. O_NOFOLLOW only guards the final component. Comparing against an
 * identity captured before the walk finished is what closes that.
 */
async function shredFile(filePath: string, expected: FileIdentity): Promise<boolean> {
  if (expected.size === 0n) return true

  const size = Number(expected.size)
  const CHUNK = 1024 * 1024 // 1 MB
  // O_NOFOLLOW is POSIX-only; on Windows the fstat comparison below carries it.
  const openFlags = fsConstants.O_RDWR | (fsConstants.O_NOFOLLOW ?? 0)
  const fh = await open(filePath, openFlags)
  try {
    const opened = await fh.stat({ bigint: true })
    const identityKnown = expected.ino !== 0n && opened.ino !== 0n
    if (
      !opened.isFile() ||
      opened.size !== expected.size ||
      (identityKnown && (opened.ino !== expected.ino || opened.dev !== expected.dev))
    ) {
      // Throw rather than return: the caller deletes whatever shredFile leaves
      // behind, so a silent skip here would still destroy the substituted file.
      throw new Error('File changed while being shredded — skipped')
    }
    // Pass 1: random data
    let offset = 0
    while (offset < size) {
      if (cancelled) return false
      const len = Math.min(CHUNK, size - offset)
      await fh.write(randomBytes(len), 0, len, offset)
      offset += len
    }
    await fh.datasync()

    // Pass 2: zeros
    const zeroBuf = Buffer.alloc(Math.min(CHUNK, size))
    offset = 0
    while (offset < size) {
      if (cancelled) return false
      const len = Math.min(CHUNK, size - offset)
      await fh.write(zeroBuf, 0, len, offset)
      offset += len
    }
    await fh.datasync()
    return true
  } finally {
    await fh.close()
  }
}

const MAX_DEPTH = 50

/**
 * Collect all file paths within a directory recursively.
 * Skips symlinks and protected paths, respects a depth limit.
 * Sets `state.depthExceeded` if any branch is cut short by MAX_DEPTH.
 *
 * Records each file's identity as it is found. That identity is what the shred
 * pass verifies against — captured here, while the path is known to resolve
 * inside the walked tree, rather than re-derived later from a path whose
 * ancestors may since have been swapped.
 */
async function collectFiles(
  dirPath: string,
  files: string[],
  identities: Map<string, FileIdentity>,
  state: { depthExceeded: boolean },
  depth: number = 0
): Promise<void> {
  if (depth >= MAX_DEPTH) {
    state.depthExceeded = true
    return
  }
  try {
    const entries = await readdir(dirPath, { withFileTypes: true })
    for (const entry of entries) {
      if (entry.isSymbolicLink()) continue
      const fullPath = join(dirPath, entry.name)
      if (entry.isDirectory()) {
        if (isProtectedPath(fullPath)) continue
        await collectFiles(fullPath, files, identities, state, depth + 1)
      } else if (entry.isFile()) {
        const identity = await readIdentity(fullPath)
        if (!identity) continue
        files.push(fullPath)
        identities.set(fullPath, identity)
      }
    }
  } catch {
    // Skip inaccessible directories
  }
}

/**
 * Remove empty directories bottom-up.  Uses rmdir() (not rm -rf) so it
 * only succeeds on truly empty directories — any un-shredded files that
 * were beyond the depth cutoff are safely preserved.
 */
async function removeEmptyDirs(dirPath: string, depth: number = 0): Promise<void> {
  if (depth >= MAX_DEPTH) return
  try {
    const entries = await readdir(dirPath, { withFileTypes: true })
    for (const entry of entries) {
      if (entry.isSymbolicLink()) continue
      if (entry.isDirectory()) {
        const childPath = join(dirPath, entry.name)
        if (isProtectedPath(childPath)) continue
        await removeEmptyDirs(childPath, depth + 1)
      }
    }
    // Try to remove this directory — only works if now empty
    await rmdir(dirPath)
  } catch {
    // Not empty or inaccessible — leave it alone
  }
}

/**
 * Get the total size of an entry (file size, or recursive directory size).
 */
async function getEntrySize(entryPath: string, depth: number = 0): Promise<number> {
  if (depth >= MAX_DEPTH) return 0
  try {
    const stats = await lstat(entryPath)
    if (stats.isSymbolicLink()) return 0
    if (stats.isFile()) return stats.size
    if (stats.isDirectory()) {
      let total = 0
      const entries = await readdir(entryPath, { withFileTypes: true })
      for (const entry of entries) {
        if (entry.isSymbolicLink()) continue
        total += await getEntrySize(join(entryPath, entry.name), depth + 1)
      }
      return total
    }
  } catch {
    /* skip */
  }
  return 0
}

export function registerFileShredderIpc(getWindow: WindowGetter): void {
  // File/folder pickers — Linux/macOS omit parent (see open-dialog.ts).
  ipcMain.handle(IPC.SHREDDER_SELECT_FILES, async () => {
    const win = getWindow()
    if (!win) return []
    const fileOpts: Electron.OpenDialogOptions = { properties: ['openFile', 'multiSelections'] }
    const result = await showOpenDialog(win, fileOpts)
    if (result.canceled || !result.filePaths.length) return []

    const entries: ShredderEntry[] = []
    for (const filePath of result.filePaths) {
      try {
        const s = await stat(filePath)
        entries.push({
          path: filePath,
          name: filePath.split(/[\\/]/).pop() || filePath,
          size: s.size,
          isDirectory: false
        })
      } catch {
        /* skip */
      }
    }
    return entries
  })

  ipcMain.handle(IPC.SHREDDER_SELECT_FOLDERS, async () => {
    const win = getWindow()
    if (!win) return []
    const folderOpts: Electron.OpenDialogOptions = {
      properties: ['openDirectory', 'multiSelections']
    }
    const result = await showOpenDialog(win, folderOpts)
    if (result.canceled || !result.filePaths.length) return []

    const entries: ShredderEntry[] = []
    for (const dirPath of result.filePaths) {
      try {
        const size = await getEntrySize(dirPath)
        entries.push({
          path: dirPath,
          name: dirPath.split(/[\\/]/).pop() || dirPath,
          size,
          isDirectory: true
        })
      } catch {
        /* skip */
      }
    }
    return entries
  })

  // Cancel
  ipcMain.handle(IPC.SHREDDER_CANCEL, () => {
    cancelled = true
  })

  // Shred
  ipcMain.handle(IPC.SHREDDER_SHRED, async (_event, paths: unknown): Promise<ShredderResult> => {
    cancelled = false
    const startTime = Date.now()
    const win = getWindow()
    const emptyResult: ShredderResult = {
      shredded: 0,
      failed: 0,
      bytesShredded: 0,
      duration: 0,
      errors: [],
      cancelled: false
    }

    if (!Array.isArray(paths)) return emptyResult
    const safePaths = paths.filter((p): p is string => typeof p === 'string' && isAbsolute(p))
    if (safePaths.length === 0) return emptyResult

    // Reject any protected paths before doing any work
    const errors: { path: string; reason: string }[] = []
    const allowedPaths: string[] = []
    for (const p of safePaths) {
      if (isProtectedPath(p)) {
        errors.push({ path: p, reason: 'Protected system path — shredding blocked' })
      } else {
        allowedPaths.push(p)
      }
    }

    // First, collect all individual files to shred
    const allFiles: string[] = []
    const dirPaths: string[] = []
    const identities = new Map<string, FileIdentity>()
    const collectState = { depthExceeded: false }

    for (const p of allowedPaths) {
      try {
        const s = await lstat(p)
        if (s.isSymbolicLink()) continue
        if (s.isDirectory()) {
          dirPaths.push(p)
          await collectFiles(p, allFiles, identities, collectState)
        } else if (s.isFile()) {
          const identity = await readIdentity(p)
          if (!identity) continue
          allFiles.push(p)
          identities.set(p, identity)
        }
      } catch {
        /* skip */
      }
    }

    // Deduplicate — overlapping selections (parent + child folder, or
    // a folder and an explicit file inside it) would otherwise shred
    // the same file twice, inflating progress and reporting a bogus
    // ENOENT failure on the second attempt.
    const uniqueFiles = [...new Set(allFiles)]

    // Calculate total bytes
    let totalBytes = 0
    const fileSizes = new Map<string, number>()
    for (const f of uniqueFiles) {
      try {
        const s = await stat(f)
        fileSizes.set(f, s.size)
        totalBytes += s.size
      } catch {
        fileSizes.set(f, 0)
      }
    }

    let shredded = 0
    let failed = errors.length
    let bytesShredded = 0
    let lastReport = Date.now()

    // Shred each file
    for (const filePath of uniqueFiles) {
      if (cancelled) break

      const now = Date.now()
      if (now - lastReport > 300) {
        lastReport = now
        sendProgress(win, {
          currentPath: filePath,
          filesShredded: shredded,
          totalFiles: uniqueFiles.length,
          bytesShredded,
          totalBytes,
          progress: totalBytes > 0 ? (bytesShredded / totalBytes) * 100 : 0
        })
      }

      try {
        const identity = identities.get(filePath)
        if (!identity) throw new Error('File was not verified during collection — skipped')
        if (!(await shredFile(filePath, identity))) {
          failed++
          errors.push({
            path: filePath,
            reason: 'Cancelled before the overwrite finished — file was not deleted'
          })
          break
        }
        await rm(filePath, { force: true })
        const fileSize = fileSizes.get(filePath) || 0
        bytesShredded += fileSize
        shredded++
      } catch (err: any) {
        failed++
        errors.push({ path: filePath, reason: err?.message || 'Unknown error' })
      }
    }

    // Remove emptied directories bottom-up.
    // If the depth limit was hit, some files beyond MAX_DEPTH were never
    // collected and therefore never shredded — using recursive rm would
    // silently delete them without the overwrite pass.  rmdir() only
    // succeeds on empty directories, so un-shredded files are preserved.
    if (!cancelled) {
      for (const dirPath of dirPaths) {
        await removeEmptyDirs(dirPath)
      }
    }

    const wasCancelled = cancelled

    // Final progress — reflect actual state, not a blanket 100 %
    sendProgress(win, {
      currentPath: '',
      filesShredded: shredded,
      totalFiles: uniqueFiles.length,
      bytesShredded,
      totalBytes,
      progress: wasCancelled ? (totalBytes > 0 ? (bytesShredded / totalBytes) * 100 : 0) : 100
    })

    return {
      shredded,
      failed,
      bytesShredded,
      duration: Date.now() - startTime,
      errors,
      cancelled: wasCancelled
    }
  })

  // Open file location
  ipcMain.handle(IPC.SHREDDER_OPEN_LOCATION, (_event, filePath: unknown) => {
    if (typeof filePath !== 'string' || !isAbsolute(filePath)) return
    shell.showItemInFolder(filePath)
  })
}
