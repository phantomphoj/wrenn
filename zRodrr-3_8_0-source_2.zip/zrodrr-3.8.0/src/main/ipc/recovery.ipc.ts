import { dialog, ipcMain, shell } from 'electron'
import { mkdir, readdir, lstat, writeFile } from 'fs/promises'
import { join } from 'path'
import { IPC } from '../../shared/channels'
import { getBackupDir } from '../services/backup-dir'
import {
  listRecoveryEntries,
  listRecoveryPage,
  removeRecoveryEntry
} from '../services/recovery-store'
import { restoreRecoveryEntry } from '../services/recovery'
import {
  listRegistryBackups,
  resolveBackupFile,
  restoreRegistryBackup
} from '../services/registry-backups'
import { getGameModeStatus } from './game-mode.ipc'

export function registerRecoveryIpc(): void {
  ipcMain.handle(IPC.RECOVERY_LIST, async (_event, offset: unknown = 0) => {
    if (!Number.isInteger(offset) || Number(offset) < 0 || Number(offset) > 5000)
      throw new Error('Invalid recovery page')
    const page = await listRecoveryPage(Number(offset))
    const backups: Array<{ name: string; size: number; modifiedAt: string }> = []
    const directory = getBackupDir()
    try {
      const files = await readdir(directory, { withFileTypes: true })
      for (const f of files
        // Privacy-trace backups keep their own prefix so each feature prunes only its own files.
        .filter(
          (f) =>
            f.isFile() && /^(?:registry|privacy-traces)-backup-[A-Za-z0-9_.-]+\.reg$/.test(f.name)
        )
        .slice(0, 100)) {
        const info = await lstat(join(directory, f.name))
        if (info.isFile() && !info.isSymbolicLink())
          backups.push({ name: f.name, size: info.size, modifiedAt: info.mtime.toISOString() })
      }
    } catch (error: any) {
      if (error.code !== 'ENOENT') throw error
    }
    return {
      ...page,
      backups,
      gameMode: process.platform === 'win32' ? getGameModeStatus() : null
    }
  })
  ipcMain.handle(IPC.RECOVERY_REMOVE, (_event, id: unknown) => removeRecoveryEntry(id))
  ipcMain.handle(IPC.RECOVERY_RESTORE, (_event, id: unknown) => restoreRecoveryEntry(id))
  ipcMain.handle(IPC.RECOVERY_OPEN_BACKUPS, async () => {
    // The list handler tolerates a missing folder (fresh install, or a
    // configured path nothing has written to yet), so create it here rather
    // than hand a nonexistent path to the OS file manager.
    const dir = getBackupDir()
    await mkdir(dir, { recursive: true })
    const error = await shell.openPath(dir)
    if (error) throw new Error(error)
  })
  ipcMain.handle(IPC.RECOVERY_REGISTRY_BACKUPS, () => listRegistryBackups())
  ipcMain.handle(IPC.RECOVERY_REGISTRY_RESTORE, (_event, name: unknown) =>
    restoreRegistryBackup(name)
  )
  ipcMain.handle(IPC.RECOVERY_SHOW_BACKUP, async (_event, name: unknown) => {
    shell.showItemInFolder((await resolveBackupFile(name)).path)
  })
  ipcMain.handle(IPC.RECOVERY_EXPORT, async () => {
    const entries = await listRecoveryEntries()
    const result = await dialog.showSaveDialog({
      defaultPath: 'kudu-recovery-history.json',
      filters: [{ name: 'JSON', extensions: ['json'] }]
    })
    if (result.canceled || !result.filePath) return false
    await writeFile(result.filePath, JSON.stringify(entries, null, 2), 'utf8')
    return true
  })
}
