import { useCallback, useEffect, useRef, useState } from 'react'
import { Check, Monitor, Moon, Sun } from 'lucide-react'
import { useLocation } from 'react-router-dom'
import { Sidebar } from './Sidebar'
import { AdminBanner } from './AdminBanner'
import { useSettingsStore } from '@/stores/settings-store'
import { usePlatform } from '@/hooks/usePlatform'
import logoSrc from '@/assets/logo.png'

/** Applies the glass/wallpaper settings to <html> so the stylesheet can react to them. */
function useAppearance() {
  const appearance = useSettingsStore((s) => s.settings.appearance)
  useEffect(() => {
    const root = document.documentElement
    const glass = appearance?.frostedGlass ?? true
    const hasWallpaper = !!appearance?.wallpaperType
    root.dataset.glass = glass ? 'on' : 'off'
    root.dataset.wallpaper = hasWallpaper ? 'on' : 'off'
    root.style.setProperty('--glass-blur', `${appearance?.glassBlur ?? 18}px`)
    root.style.setProperty('--glass-tint', `${appearance?.glassOpacity ?? 55}%`)
    return () => {
      delete root.dataset.glass
      delete root.dataset.wallpaper
    }
  }, [appearance?.frostedGlass, appearance?.glassBlur, appearance?.glassOpacity, appearance?.wallpaperType])
}

function WallpaperLayer() {
  const appearance = useSettingsStore((s) => s.settings.appearance)
  const videoRef = useRef<HTMLVideoElement>(null)
  const type = appearance?.wallpaperType
  const src = `zrodrr-media://wallpaper/?v=${appearance?.wallpaperVersion ?? 0}`

  // Pause the video while the window is hidden or minimised to save CPU/battery.
  useEffect(() => {
    if (type !== 'video') return
    const onVisibility = () => {
      const v = videoRef.current
      if (!v) return
      if (document.hidden) v.pause()
      else v.play().catch(() => {})
    }
    document.addEventListener('visibilitychange', onVisibility)
    return () => document.removeEventListener('visibilitychange', onVisibility)
  }, [type])

  if (!type) return null
  return (
    <div className="wallpaper-layer" aria-hidden="true">
      {type === 'video' ? (
        <video
          key={src}
          ref={videoRef}
          src={src}
          autoPlay
          loop
          muted
          playsInline
          disablePictureInPicture
        />
      ) : (
        <img key={src} src={src} alt="" draggable={false} />
      )}
      <div
        className="wallpaper-dim"
        style={{ background: `rgba(0, 0, 0, ${(appearance?.wallpaperDim ?? 30) / 100})` }}
      />
    </div>
  )
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const location = useLocation()
  const { platform } = usePlatform()
  useAppearance()
  const handleSkip = useCallback((e: React.MouseEvent | React.KeyboardEvent) => {
    e.preventDefault()
    const el = document.getElementById('main-content')
    if (el) {
      el.focus()
      el.scrollIntoView()
    }
  }, [])

  return (
    <>
      <WallpaperLayer />
    <div className="app-shell h-screen overflow-hidden" data-platform={platform}>
      <a href="#" className="skip-nav" onClick={handleSkip}>
        Skip to main content
      </a>

      <header className="app-titlebar drag-region" aria-label="zRodrr window titlebar">
        <div className="app-brand">
          <img src={logoSrc} alt="" className="h-6 w-6 rounded-full" />
          <div>
            <div
              className="text-[12px] font-bold leading-none"
              style={{ color: 'var(--text-primary)' }}
            >
              zRodrr
            </div>
          </div>
        </div>
        <div className="app-titlebar-drag flex-1" aria-hidden="true" />
        <div className="app-titlebar-actions no-drag flex h-full items-center">
          <AppearanceMenu />
        </div>
      </header>

      <div className="flex min-h-0 flex-1 overflow-hidden">
        <Sidebar />
        <div className="relative flex min-w-0 flex-1 flex-col overflow-hidden">
          <AdminBanner />
          <main
            id="main-content"
            data-route={location.pathname}
            tabIndex={-1}
            className="app-content relative flex-1 overflow-y-auto outline-none"
          >
            {children}
          </main>
        </div>
      </div>
    </div>
    </>
  )
}

type ThemeMode = 'system' | 'light' | 'dark'

function AppearanceMenu() {
  const theme = useSettingsStore((s) => s.settings.theme)
  const updateSettings = useSettingsStore((s) => s.updateSettings)
  const [open, setOpen] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)
  const options: { id: ThemeMode; label: string; description: string; icon: typeof Sun }[] = [
    { id: 'system', label: 'System', description: 'Follow your computer', icon: Monitor },
    { id: 'light', label: 'Light', description: 'Warm daylight', icon: Sun },
    { id: 'dark', label: 'Dark', description: 'Low-light comfort', icon: Moon }
  ]
  const active = options.find((option) => option.id === theme) ?? options[0]
  const ActiveIcon = active.icon

  useEffect(() => {
    if (!open) return
    const close = (event: PointerEvent) => {
      if (!menuRef.current?.contains(event.target as Node)) setOpen(false)
    }
    window.addEventListener('pointerdown', close)
    return () => window.removeEventListener('pointerdown', close)
  }, [open])

  const selectTheme = (nextTheme: ThemeMode) => {
    updateSettings({ theme: nextTheme })
    window.kudu?.settingsSet?.({ theme: nextTheme }).catch(() => {})
    setOpen(false)
  }

  return (
    <div className="relative" ref={menuRef}>
      <button
        type="button"
        className="titlebar-icon-button"
        aria-label={`Appearance: ${active.label}`}
        aria-expanded={open}
        aria-haspopup="menu"
        title={`Appearance: ${active.label}`}
        onClick={() => setOpen((value) => !value)}
      >
        <ActiveIcon className="h-3.5 w-3.5" strokeWidth={1.8} />
      </button>
      {open && (
        <div className="appearance-menu animate-scale-in" role="menu" aria-label="Appearance">
          <div
            className="px-3 pb-2 pt-2.5 text-[9px] font-bold uppercase tracking-[0.16em]"
            style={{ color: 'var(--text-dim)' }}
          >
            Appearance
          </div>
          {options.map((option) => {
            const Icon = option.icon
            const selected = option.id === theme
            return (
              <button
                key={option.id}
                type="button"
                role="menuitemradio"
                aria-checked={selected}
                onClick={() => selectTheme(option.id)}
              >
                <span className="appearance-option-icon">
                  <Icon className="h-4 w-4" strokeWidth={1.8} />
                </span>
                <span className="min-w-0 flex-1 text-left">
                  <b>{option.label}</b>
                  <small>{option.description}</small>
                </span>
                {selected && (
                  <Check
                    className="h-3.5 w-3.5"
                    style={{ color: 'var(--brand-solid)' }}
                    strokeWidth={2.4}
                  />
                )}
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}
